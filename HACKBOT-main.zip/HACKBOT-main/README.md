# Powered By @LegendBot_XD

## ⚠️ Note : Dont Try To Missuse This Repo

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

